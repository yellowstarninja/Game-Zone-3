/**
 * Handles the intro
 *
 * Brian Call
 * 4.1.24
 */
import javax.swing.*;
public class IntroVisitor
{
    public static void OpenBox() //Contains the Opening Text Box
    {
        System.out.println("==================================");
        System.out.println("||                              ||");
        System.out.println("||      Welcome to GTKGU!       ||");
        System.out.println("||                              ||");
        System.out.println("||      \"Get To Know Guam\"      ||");
        System.out.println("||        By Brian Call         ||");
        System.out.println("||                              ||");
        System.out.println("==================================");
    }
    
    public static void Intro() //Uses the opening-name-ask segment
    {
       String name = JOptionPane.showInputDialog(null, "What's you name?");
       JOptionPane.showMessageDialog(null, "Hello, " + name);
    }
    
    public static void CloseBox()//Contains the Close Box
    {
        System.out.println("==================================");
        System.out.println("||                              ||");
        System.out.println("||  Thank you for using GTKGU!  ||");
        System.out.println("||                              ||");
        System.out.println("||      \"Get To Know Guam\"      ||");
        System.out.println("||        By Brian Call         ||");
        System.out.println("||                              ||");
        System.out.println("==================================");
    }
}
