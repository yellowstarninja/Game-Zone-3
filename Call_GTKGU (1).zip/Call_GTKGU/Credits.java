
/**
 * Write a description of class Credits here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Credits
{
    public static void Credits()
    {
        TextArts.SlowPrint("World Text Art: https://ascii.co.uk/art/world", true);
        TextArts.SlowPrint("Palm Tree Art: https://textart.sh/topic/palm", true);
        TextArts.SlowPrint("Guam Facts: https://www.britannica.com/place/Guam", true);
        TextArts.SlowPrint("Guam Timeline: https://www.guampedia.com/guams-seven-historical-eras/", true); //prints the end credits
    }
}
