/**
 * Main body that is brings together all of the code from the other boxes
 * 
 * Brian Call
 * 4.1.24
 */
import javax.swing.*;
import java.util.Scanner;
public class GTKGU
{   
    public static void main(String[] args)
    {
         IntroVisitor.OpenBox(); //Opening Box
         IntroVisitor.Intro(); //Asks for and prints name
         System.out.println(""); 
         TextArts.SlowPrint("Hey, welcome to GTKGU!", true);

         
         int index = 0;
         while(index != 4)
         {
            index = askPrompt(true); //Failsafe in case the "askPrompt" loop accidentally ends, and requires the user to send 4
         }
         TextArts.SlowPrint("Thank you! Bye!", true);
         System.out.println();
         IntroVisitor.CloseBox(); //Ends the program, and prints the CloseBox
         Credits.Credits(); //Prints Credits
    }
    
    public static int askPrompt(boolean first)
    {
        if(!first)
        {
            TextArts.Wait(3000); //Stalls before clearing so the transition isn't jarring
            System.out.print('\u000C'); //Clears the screen
        }
        TextArts.Palm(); //Prints the Palm Tree
        System.out.println("----------------------");
        System.out.println("");
        Scanner input = new Scanner(System.in); //Assigns the Scanner Object
        TextArts.SlowPrint("Select which of the following games you want to learn from!", true); //Prints the options to select from
        TextArts.SlowPrint("#1: Guam Geography", true);
        TextArts.SlowPrint("#2: Guam Trivia", true);
        TextArts.SlowPrint("#3: Guam Timeline", true);
        
        if(!first) //If they've been to one of the games, it allows them to quit the program
        {
            TextArts.SlowPrint("#4: End Program", true); //Prints the option
        }
        
        TextArts.SlowPrint("Select the number you want: ", false);
        int index = Integer.parseInt(input.nextLine()); //Gathers the option
        FactsGU.RandomFact(); //Prints the random fact
        boolean loop = false;   
        while(!loop){
            switch(index) //Checks the option and takes you to the correct game
            {
                case(1):
                    LearnGU.StartGeo();
                    loop = true; //Loop to check if you are allowed to use 4
                    break;
                    
                case(2):
                    LearnGU.StartTrivia();
                    loop = true;
                    break;
                    
                case(3):
                    LearnGU.StartTime();
                    loop = true;
                    break;
                    
                case(4):
                    if(first)
                    {
                        loop = true;
                    }
                    break;
            }
        }
        return 4;
    }
}
