/**
 * Handles all text arts and text related function
 *
 * Brian Call
 * 4.1.24
 */
import java.io.*;
public class TextArts
{
    public static void Palm() //Palm Text Art
    {
      System.out.println("");   
      System.out.println("                        ██                                  ");
      System.out.println("                          ██                                ");
      System.out.println("                          ▓▓██                              ");
      System.out.println("                            ▒▒▓▓▒▒                          ");
      System.out.println("                            ▓▓▒▒░░██                        ");
      System.out.println("                  ████████    ██▒▒░░██                     "); 
      System.out.println("          ░░▓▓▓▓▓▓░░░░░░░░▓▓▓▓▓▓▓▓▒▒██                   ");   
      System.out.println("        ██░░▒▒▒▒▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒████░░██                 ");   
      System.out.println("      ██░░▒▒▓▓██▓▓▓▓▓▓▓▓▓▓▒▒▓▓▓▓▒▒▓▓▓▓▓▓██████████      ");    
      System.out.println("  ██▓▓██▓▓██        ████▓▓▓▓██▓▓▓▓██░░░░▒▒░░░░░░░░▓▓▓▓    ");  
      System.out.println("▒▒▒▒            ▒▒▒▒▒▒▒▒██▒▒▒▒▒▒▒▒░░▒▒▒▒░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒  ");
      System.out.println("            ████░░▒▒▒▒▓▓██▓▓▓▓▓▓██████▓▓████████        ████");
      System.out.println("          ▓▓░░▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓██▒▒██▒▒██░░░░▓▓             "); 
      System.out.println("        ██░░▒▒▓▓██  ████▒▒▓▓▓▓██▓▓▓▓████▒▒▒▒░░████        ");  
      System.out.println("        ██▒▒▓▓██  ██▒▒▓▓▓▓▓▓████▓▓▓▓▓▓██▒▒▓▓▒▒▒▒░░██     ");   
      System.out.println("      ░░▒▒▒▒▒▒    ▓▓▒▒▒▒▒▒  ▒▒▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓     ");   
      System.out.println("      ▓▓▒▒▓▓    ▓▓▓▓▓▓    ▒▒▒▒▓▓▓▓██▓▓▒▒░░░░▓▓▓▓▓▓░░▓▓     "); 
      System.out.println("    ██▒▒██      ████    ▓▓░░▒▒██▓▓▓▓██▓▓▒▒░░██  ████░░      ");
      System.out.println("    ████      ████    ▓▓░░▓▓    ████▓▓██▒▒░░██      ████    ");
      System.out.println("  ▓▓▓▓        ▓▓      ▒▒▒▒▒▒        ▓▓▓▓▒▒▒▒▓▓        ▓▓    ");
      System.out.println("  ██                ▓▓░░▓▓            ██▓▓▒▒░░██        ██  ");
      System.out.println("                  ▓▓░░▒▒▓▓              ▓▓▓▓░░██        ██  ");
      System.out.println("                  ▒▒░░▒▒                  ▓▓▒▒▓▓            ");
      System.out.println("                ▒▒░░▒▒▒▒                    ▓▓▓▓            ");
      System.out.println("                ▓▓░░▓▓                        ██            ");
      System.out.println("              ▓▓▒▒░░▓▓                        ████          ");
      System.out.println("              ▓▓▒▒▒▒▓▓                          ██          ");
      System.out.println("            ░░░░░░▒▒▒▒                          ▓▓          ");
      System.out.println("            ▓▓░░░░▓▓                            ██          ");
      System.out.println("            ▓▓▒▒░░▓▓                                        ");
      System.out.println("            ▓▓▒▒░░▓▓                                        ");
      System.out.println("            ▓▓░░▒▒▓▓                                        ");
      System.out.println("            ▓▓░░▒▒▓▓                                        ");
      System.out.println("            ▓▓▒▒▒▒▓▓                                        ");
      System.out.println("            ▓▓░░▒▒▓▓                                        ");
      System.out.println("              ▓▓░░▒▒▓▓                                      ");
      System.out.println("              ▓▓░░▒▒▓▓                                      ");
      System.out.println("              ▓▓▒▒░░▓▓                                      ");
      System.out.println("              ▓▓░░▒▒▒▒▓▓                                    ");
      System.out.println("              ▓▓░░░░▒▒▓▓                                    ");
      System.out.println("              ▓▓▒▒░░░░▓▓                                    ");
      System.out.println("                ▓▓▒▒▒▒▒▒▓▓                                  ");
      System.out.println("                ▓▓░░░░▒▒▓▓                                  ");
      System.out.println("                ▒▒░░░░▒▒▒▒▒▒░░                              ");
      System.out.println("            ░░▓▓░░░░░░░░░░░░░░░░                            ");
      System.out.println("          ░░░░░░░░░░░░▓▓▓▓░░░░░░░░                          ");
      System.out.println("              ░░░░░░░░░░░░░░                                ");
      System.out.println("");
      System.out.println("");
    }
    public static void WorldMap() //World Map Text Art
    {
        System.out.println("+----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+------+");
        System.out.println("|           . _..::__:  ,-\"-\"._        |7       ,     _,.__   ▓J▓       |");
        System.out.println("|   _.___ _ _<_>`!(._`.`-.    /         _._     `_ ,_/  '  '-._.---.-.__|");
        System.out.println("|>.{     \" \" `-==,',._\\{  \\  / {)      / _ \">_,-' `                mt-2_|");
        System.out.println("+  \\_.:--.       `._ )`^-. \"'       , ▓A▓(                       __,/-' +");
        System.out.println("| '\"'     \\         \"    _L        oD_,--'                )     /. (|   |");
        System.out.println("|          |   ▓G▓     ,'          _)_.\\._<> 6              _,' /  '    |");
        System.out.println("|          `.         /           [_/_'` `\"(                <'}  )      |");
        System.out.println("+           \\\\    .-. )           /   `-'\"..' `:._         ▓B▓  '       +");
        System.out.println("|    `        \\  (  `(           /         `:\\  > \\  ,-^.  /' '         |");
        System.out.println("|              `._,   \"\"         |   ▓E▓      \\`'   \\|   ?_)  {\\        |");
        System.out.println("|                 `=.---.        `._._       ,'     \"`  |' ,- '.    ▓C▓ |");
        System.out.println("+                   |    `-._         |     /          `:`<_|h--._      +");
        System.out.println("|                   (        >        .     | ,          `=.__.`-'\\     |");
        System.out.println("|                    `. ▓F▓ /         |     |{|        ▓D▓   ,-.,\\    .|");
        System.out.println("|                     |   ,'           \\   / `'            ,\"     \\     |");
        System.out.println("+                     |  /              |_'                |  __  /     +");
        System.out.println("|                     | |                                  '-'  `-'  \\. |");
        System.out.println("|      ▓H▓            |/                                         \"   / |");
        System.out.println("|                     \\.                                             '  |");
        System.out.println("+                                                                       +");
        System.out.println("|                      ,/            ______._.--._ _..---.---------._   |");
        System.out.println("|     ,-----\"-..?----_/ )      __,-'\"             \"                  (  |");
        System.out.println("|-.._(                  `-----'                 ▓I▓                   `-|");
        System.out.println("+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+");
    }
 
    public static void TriviaStart() //Contains Trivia Start Text
    {
        System.out.println(" ______     __  __     ______     __    __           ______   ______     __     __   __   __     ______");  
        System.out.println("/\\  ___\\   /\\ \\/\\ \\   /\\  __ \\  /\\ \"-./  \\         /\\__  _\\ /\\  == \\   /\\ \\   /\\ \\ / /  /\\ \\   /\\  __ \\ ");   
        System.out.println("\\ \\ \\__ \\  \\ \\ \\_\\ \\  \\ \\  __ \\  \\ \\ \\-./\\ \\        \\/_/\\ \\/ \\ \\  __<   \\ \\ \\  \\ \\ \\'/   \\ \\ \\  \\ \\  __ \\ ");  
        System.out.println(" \\ \\_____\\  \\ \\_____\\  \\ \\_\\ \\_\\  \\ \\_\\ \\ \\_\\          \\ \\_\\  \\ \\_\\ \\_\\  \\ \\_\\  \\ \\__|    \\ \\_\\  \\ \\_\\ \\_\\"); 
        System.out.println("  \\/_____/   \\/_____/   \\/_/\\/_/   \\/_/  \\/_/           \\/_/   \\/_/ /_/   \\/_/   \\/_/      \\/_/   \\/_/\\/_/ ");
    }

    public static void TimeStart() //Contains Time Start Palm Tree Text
    {
        System.out.println("                __..-----') ");
        System.out.println("       ,.--._ .-'_..--...-' ");
        System.out.println("      '-\"'. _/_ /  ..--''\"\"'-. ");
        System.out.println("      _.--\"\"...:._:(_ ..:\"::. \\");
        System.out.println("   .-' ..::--\"\"_(##)#)\"':. \\ \\)    \\ _|_ /");
        System.out.println("  /_:-:'/  :__(##)##)    ): )   '-./'   '\\.-'");
        System.out.println("  \"  / |  :' :/\"\"\\///)  /:.'    --(       )--");
        System.out.println("    / :( :( :(   (#//)  \"       .-'\\.___./'-.");
        System.out.println("   / :/|\\ :\\_:\\   \\#//\\            /  |  \\");
        System.out.println("   |:/ | \"\"--':\\   (#//)              '");
        System.out.println("   \\/  \\ :|  \\ :\\  (#//)");
        System.out.println("        \\:\\   '.':. \\#//\\");
        System.out.println("         ':|    \"--'(#///)");
        System.out.println("                    (#///)");
        System.out.println("                    (#///)");
        System.out.println("                     \\#///\\");
        System.out.println("                     (##///)");
        System.out.println("                     (##///)");
        System.out.println("                     (##///)");
        System.out.println("                     (##///)");
        System.out.println("                      \\##///\\");
        System.out.println("                      (###///)");
        System.out.println("                      (###////)__...-----....__");
        System.out.println("                      (#/::'''                 \"\"--.._");
        System.out.println("                 __..-'''                             \"-._");
        System.out.println("         __..--\"\"                                         '._");
        System.out.println("___..--\"\"                                                    \"-..____");
        System.out.println("  (_ \"\"---....___                                     __...--\"\" _)");
        System.out.println("    \"\"\"--...  ___\"\"\"\"\"-----......._______......----\"\"\"     --\"\"\"");
        System.out.println("                  \"\"\"\"       ---.....   ___....----");
    }
    
    public static void SlowPrint(String givenStr, boolean lBreak) //
    {
        for(int i = 0; i < givenStr.length(); i++) //Breaks the string into characters and prints them individually
        {
            System.out.print(givenStr.charAt(i));
            Wait(30); //Stall
        }
         
        if(lBreak) //If it asks a linebreak, it does it
            System.out.println(); 
    }
    
    public static void Wait(long pause) //Function used to stall the program
    {
        try
        {
            Thread.sleep(pause);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
