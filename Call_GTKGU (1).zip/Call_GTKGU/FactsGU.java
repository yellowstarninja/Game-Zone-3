/**
 * Stores all of the random facts, and prints them (it also clears the screen for the transition)
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Random;
public class FactsGU
{
    public static String tempString;
    public static void RandomFact()
    {
        System.out.print('\u000C'); //CLEARS THE SCREEN WITH THE NEW TRANSITION
        String[] facts = new String[]{"Guam is the largest and most populated of the Mariana Islands", //Contains all of the "fun facts"
            "Guam is split between a limestone plateau and volcanic hills",
            "Guam's temperature ranges between 70 and 90 degrees Farenheit",
            "The word Chamorro (the native culture of Guam), is derived from Chamorri, meaning \"noble\"",
            "Chamorro citizens became US Citizens in the Organic Act on August 1st, 1950",
            "The Micronesia Mall is the largest shopping center on the island",
            "Patron saints frequently have fiestas held in commemoration throughout the island",
            "The common house foundation pillar stones were called \"latte\" (la-di)",
            "Annual Guam precipitation is around 95 inches",
            "Tourism is the most prominent component of the Guam economy"}; 
            
        Random rand = new Random(); //Creates the random object
        int randomNum = rand.nextInt(facts.length); //Generates a random number 
        
        System.out.println("");
        TextArts.SlowPrint("--------------------------", true);
        TextArts.SlowPrint("Fun Fact! " + facts[randomNum], true); //Uses the random number to generate a random one of the facts
        TextArts.SlowPrint("--------------------------", true);
        System.out.println("");
        
        tempString = facts[randomNum]; //Gathers the random fact to print when the screen is cleared in the timeline game
    }
}
