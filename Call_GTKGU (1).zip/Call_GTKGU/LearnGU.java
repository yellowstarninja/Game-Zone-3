/**
 * Handles the actual games
 *
 * Brian Call
 * 4.1.24
 */
import java.util.*;
public class LearnGU
{
    static String[] uPieces = {"____________", "___________", "____________",
        "_____________", "___________", "_____________", "_______"}; //Contains an empty list to use for the Timeline
    static int[] uDates = {0, 0, 0, 0, 0, 0, 0}; //Contains empty list of Dates to use for the timeline
    static String[] aPieces = {"Ancient Guam", "Spanish Era", "US Naval Era", //Contains the correct answers
        "Japanese Era", "Post-War Era", "Guamanian Era", "Present"};
    static int[] aDates = {2000, 1668, 1898, 1941, 1944, 1950, 1970}; //Contains the correct dates
    static int difficulty = 0; //Global variable for the difficulty to keep it when it clears
    static boolean finished = false; //Checks if you've finished the program to see if it needs to loop automatically
    
    public static void StartGeo()
    {
        Scanner input = new Scanner(System.in); //Scanner Object definition
        
        TextArts.WorldMap();//Prints the world Map
        TextArts.SlowPrint("Which letter is the position of Japan?: ",false);
        String answer;//Predefines the answer to prevent a "may not be defined" error
        
        boolean loopCheck = false;
        while(!loopCheck)//Checks for incorrect vs correct answers
        {
            answer = input.nextLine();//Takes answer
            if(answer.equals("B") || answer.equals("b"))//Checks if you're correct
            {
                loopCheck = true; //Ends the loop
            }
            else
            {
                TextArts.SlowPrint("Incorrect. Try again: ", false);//Prints that you're wrong
            }
        }
        
        TextArts.SlowPrint("Correct! Which letter is the position of America?: ",false); //Congrats message
        
       
        loopCheck = false;//Resets the variable
        while(!loopCheck)//Loops if you're wrong
        {
            answer = input.nextLine();//Takes answer
            if(answer.equals("G") || answer.equals("g"))//Checks correct answer
            {
                loopCheck = true; //Ends loop
            }
            else
            {
                TextArts.SlowPrint("Incorrect. Try again: ", false); //Prints wrong
            }
        }
        
        TextArts.SlowPrint("Correct! Which letter is the position of Guam?: ",false);//Congrats message
        
        loopCheck = false;//Resets variable
        while(!loopCheck)//Loops wrong
        {
            answer = input.nextLine();//Takes answer
            if(answer.equals("C") || answer.equals("c"))//Checks answer
            {
                loopCheck = true;//Ends loop
            }
            else
            {
                TextArts.SlowPrint("Incorrect. Try again: ", false);//Prints wrong
            }
        }
        
        TextArts.SlowPrint("Good job!", true); //Congrats
        System.out.println("----------------------");
        System.out.println("");
        GTKGU.askPrompt(false);//Resets to the opening Page
    }
    
    public static void StartTrivia()
    {
        Scanner input = new Scanner(System.in);//Scanner Object
        
        int correctAnswers = 0;//Creates correct answer int
        
        TextArts.TriviaStart();//Opening TextArt
        TextArts.SlowPrint("Welcome to Guam Trivia! Answer the questions with the corresponding letter!", true);
        System.out.println();
        
        TextArts.SlowPrint("Question 1: Who is the current govenor of Guam?", true);
        String[] pAnswers = { "Lou Guerrero", "Grana Balbastro", "Alana Cruz", "Don Quixote", null};//Creates the possible answers
        String cAnswer = OrderScrambler(pAnswers, 0);//Scrambles the answers and returns the correct answer
        
        System.out.println();
        TextArts.SlowPrint("Select the correct answer: ", false);
        String answer = input.nextLine();//Takes answer

        if(answer.equals(cAnswer.toUpperCase()) || answer.equals(cAnswer.toLowerCase()))//Checks for correct answer regardless of whether or not its lowercase or uppercase
        {
            TextArts.SlowPrint("Correct! Good job!", true);
            correctAnswers++; //Adds to the correct
        }
        else
        {
            TextArts.SlowPrint("Incorrect. The correct answer was " + cAnswer + ", Lou Guerrero!", true); //Tells you if you were wrong + the answer
        }

        System.out.println();
        System.out.println("-------------------------------");
        TextArts.SlowPrint("Question 2: What was the name of the most recent hurricane?", true);
        String[] pAnswers2 = { "Katrina", "Mario", "Spielberg", "Mawar", null}; //Stores possible answers
        cAnswer = OrderScrambler(pAnswers2, 3);//Shuffles the the answers and returns correct
        
        System.out.println();
        TextArts.SlowPrint("Select the correct answer: ", false);
        answer = input.nextLine();//Takes answer

        if(answer.equals(cAnswer.toUpperCase()) || answer.equals(cAnswer.toLowerCase())) //Checks the answer
        {
            TextArts.SlowPrint("Correct! Good job!", true); 
            correctAnswers++;//Add to correct
        }
        else
        {
            TextArts.SlowPrint("Incorrect. The correct answer was " + cAnswer  + ", Mawar!", true);//Wrong print + correct answer
        }
        
        System.out.println();
        System.out.println("-------------------------------");
        TextArts.SlowPrint("Question 3: Where is Lover's Point?", true); 
        String[] pAnswers3 = { "Tamuning", "Yigo", "Tokyo", "Dededo", null}; //Stores possible answers
        cAnswer = OrderScrambler(pAnswers3, 0);//Shuffles the the answers and returns correct
        
        System.out.println();
        TextArts.SlowPrint("Select the correct answer: ", false);
        answer = input.nextLine();//Takes answer

        if(answer.equals(cAnswer.toUpperCase()) || answer.equals(cAnswer.toLowerCase()))//Checks the answer
        {
            TextArts.SlowPrint("Correct! Good job!", true);
            correctAnswers++;//Add to correct
        }
        else
        {
            TextArts.SlowPrint("Incorrect. The correct answer was " + cAnswer  + ", Tamuning!", true);//Wrong print + correct answer
        }

        System.out.println("----------------------");
        System.out.println("");
        TextArts.SlowPrint("Congratulations! You got " + correctAnswers, true); //Prints how many answers you got correct
        switch(correctAnswers)//Dynamically responds with an evaluation depending on correct count
        {
            case(0):
                TextArts.SlowPrint("Which, I'll be honest, is not that great.",true);
                return;
            case(1):
                TextArts.SlowPrint("You could've done worse.",true);
                return;
            case(2):
                TextArts.SlowPrint("Near perfect!",true);
                return;
            case(3):
                TextArts.SlowPrint("Perfect job! Way to go!",true);
                return;
        }
        System.out.println("----------------------");
        System.out.println("");
        GTKGU.askPrompt(false);//Reset to 0
    }
    
    public static String OrderScrambler(String[] str, int indexAnswer)
    {
        String answer = "E"; //Placeholder
        Random rand = new Random(); //Defines random object
        
        int randomNumber = 4;
        
        for(int i = 0; i < 4; i++)//Loops 4 times
        {
             char tempChar = (char)(i + 65); //Converts the character into unicode
             while(str[randomNumber] == null) //Makes sure it isn't a repeat answer
             {
                 randomNumber = rand.nextInt(4); //Generates a random number
             }
             
             TextArts.SlowPrint(tempChar + ": " + str[randomNumber], true); //Prints the answer
             
             str[randomNumber] = null; //Clears the answer so it isn't repeated
             if(randomNumber == indexAnswer)//Checks to see if the index returned is equal to the correct index
             {
                 answer = Character.toString(tempChar); //Sets the correct letter to the one matched with the correct letter
             }
        }
        
        return answer;//Returns correct letter
    }
    
    public static void StartTime()
    {
        difficulty = 0; //Resets variables for looping
        finished = false; 
        String[] tempUPieces = {"____________", "___________", "____________", "_____________", "___________", "_____________", "_______"};
        uPieces = tempUPieces;
        int[] tempUDates = new int[7]; 
        uDates = tempUDates;
        
        int type = OpeningCrawl(true); //Starts the user input sequence
        
        int correctCount = 0; //Define variables, this being correct answers
        int maxCorrect = 0; //This being max amount possible
        int[] incListPiece = new int[7]; //Creates an empty list to store indexes for the incorrect answer print
        int[] incListDate = new int[7]; //Creates an empty list to store indexes for the incorrect answer print
        int currentIncorrect = 0; //Used to store how many you got wrong to prevent overflow into the unused sections of the list
        int pieceFinish = 0; //Tracks the last index of incorrect answers
        int dateFinish = 0; //Tracks the last index of incorrect answer
        
        if(difficulty == 1 || difficulty == 3) //Checks if you filled names
        {
            for(int i = 0; i < uPieces.length; i++) //Loops for every element of the user answers
            {
                if(uPieces[i].equals(aPieces[i])) //Checks to see if the answer is correct
                {
                    correctCount++; //Adds 1 if correct
                }
                else
                {
                    incListPiece[currentIncorrect] = i; //Stores the index of the incorrect asnwer
                    currentIncorrect += 1; //Adds one to the number wrong
                }
            }
            maxCorrect += aPieces.length; //Adds to the maximum amount possible 
            pieceFinish = currentIncorrect; //Locks in the final index of the incorrect answers
        }
        
        if(difficulty == 2 || difficulty == 3) //Checks if you filled dates
        {
            currentIncorrect = 0; //All of this is a repeat of whats above, except this which resets the currentIncorrect variable to prevent overflow from having the index be too far forward
            for(int j = 0; j < uDates.length; j++)
            {
                if(uDates[j] == aDates[j])
                {
                    correctCount++;
                }
                else
                {
                    incListDate[currentIncorrect] = j;
                    currentIncorrect += 1;
                }
            }
            maxCorrect += aDates.length;
            dateFinish = currentIncorrect;
        }
        
        System.out.println();
        TextArts.SlowPrint("You got " + correctCount + " out of " + maxCorrect + " correct!",true); //Prints the correct : total
        if(correctCount != maxCorrect) //If you got any wrong run this
        {
            TextArts.SlowPrint("You got the following questions incorrect: ", true); 
            if(difficulty == 1 || difficulty == 3)//Checks if you did names
            {
                for(int i = 0; i < pieceFinish; i++) //Loops for the number you got wrong
                {
                    TextArts.SlowPrint("Name Slot " + incListPiece[i] + ": " + aPieces[incListPiece[i]] + " not " + uPieces[incListPiece[i]], true); //Finds the slot it was in, the incorrect and correct answer and prints them in a way that makes sense/is easy to read
                }
            }
            
            if(difficulty == 2 || difficulty == 3)//Checks if you did dates
            {
                 for(int k = 0; k < dateFinish; k++)
                {
                    TextArts.SlowPrint("Date Slot " + incListDate[k] + ": " + aDates[incListDate[k]] + " not " + uDates[incListDate[k]], true);//Same as above
                }
            }
            System.out.println();
            TextArts.SlowPrint("Thanks for playing! Try again next time!", true); //End message if you got any wrong
        }
        else
        {
            TextArts.SlowPrint("You got every question correct! Congratulations!",true); //Congratulations message if you didn't get any wrong
        }
        
        GTKGU.askPrompt(false); //Reset to 0
    }
    
    public static int OpeningCrawl(boolean firstRun)//This function is looped every time the user puts in a new answer
    {
        Scanner input = new Scanner(System.in);  
        if(!firstRun) //This is to recreate the randomly generated fact 
        { 
            System.out.println("");
            System.out.println("--------------------------");
            System.out.println("Fun Fact! " + FactsGU.tempString); //Accesses and print the randomly generated fact stored by the FactsGU script
            System.out.println("--------------------------");
            System.out.println("");
        }
        
        TextArts.TimeStart();
        System.out.println("--------------------------------");
        SpeedFF("Welcome to the Guam Timeline! Here you will learn the eras of Guam!", firstRun); //This function is used so that it will slow print the first time, but as soon as it detects its a second run, it will print instantly
        System.out.println();
        SpeedFF("Here is the full timeline of Guam!", firstRun);
        System.out.println();
        
        String[] uStrDates = {"____", "____", "____", "____", "____", "____", "____"}; //Generates user dates
        for(int i = 0; i < uDates.length; i++) //This is used to prevent a error from attempting to convert a null value into a string
        {
            if(uDates[i] != 0)
            {
                uStrDates[i] = Integer.toString(uDates[i]); //Sets the dates to the integers if they aren't blank
            }
        }
        
        if(difficulty == 0 || difficulty == 1) //Prints this if its the first run or you're not doing dates
        {
            SpeedFF("    2000 BC               1898                 1944                  1970", firstRun);
        }
        else //The alternate that fills the timeline with the users answers
        {
            SpeedFF("    " + uStrDates[0] + " BC               " + uStrDates[2] + "                " + uStrDates[4] + "                 " + uStrDates[6], firstRun);
        }
        if(difficulty == 0 || difficulty == 2) //Prints this if its the first run or if you're not doing names
        {
            SpeedFF("  Ancient Guam         US Naval Era        Post-War Era          Modern Guam", firstRun);
        } 
        else //Alternate that fills the timeline with the users answers
        {
            SpeedFF("  " + uPieces[0] + "         " + uPieces[2] + "        " + uPieces[4] + "          " + uPieces[6] + "", firstRun);
        }
        System.out.println("       ||                  ||                   ||                   ||");
        System.out.println("<<==========================================================================>>"); //Prints it fast to kill annoying waiting times
        System.out.println("               ||                   ||                    || ");
        if(difficulty == 0 || difficulty == 2) //Does the same as the second difficulty "if" statement
        {
            SpeedFF("           Spanish Era         Japanese Era         Guamanian Era ", firstRun);
        }
        else
        {
            SpeedFF("           " + uPieces[1] + "         " + uPieces[3] + "         " + uPieces[5], firstRun);
        }
        if(difficulty == 0 || difficulty == 1) //Does the same as the first difficulty "if" statement
        {
            SpeedFF("              1668                 1941                  1950", firstRun);
        }
        else
        {
            SpeedFF("              " + uStrDates[1] + "                 " + uStrDates[3] + "                  " + uStrDates[5], firstRun);
        }
        
        System.out.println();
        SpeedFF("Memorize EXACTLY what the timeline says, and when you finish, select below.", firstRun);
        SpeedFFQ("Select your difficulty on a scale of 1-3: ", firstRun); //A different function that stores your answer you added so that when it is run again, the answer still appears and isn't wiped
        if(firstRun) //Checks if it needs to check your difficulty since this its the first run
        {
            difficulty = input.nextInt();
        }
        
        if(!firstRun) //Checks if it needs to check if you should be able to add list values
        {
            finished = EnterListValue(difficulty);
        }
        
        if(!finished) //If the user said their done, let the loop end, if not clear the screen and reprint everything, looping it again
        {
            System.out.print('\u000C');
            OpeningCrawl(false);
        }
        
        return difficulty; //Return which lists the user used and end the loop
    }
    
    public static boolean EnterListValue(int difficult)
    {
        Scanner input = new Scanner(System.in);       //Defines variables 
        boolean isPiece = false; //Checks if you're using the pieces lists
        boolean tempLoop = true; //Checks if you inputted an invalid value
        boolean listPiece = false; //Checks if your Pieces list is full
        boolean listDate = false; //Checks if your date list is full
        int listCount = 0; //Variable for checking if your list is full
        
        if(difficulty == 1 || difficulty == 3) //Checks if your doing names
        {
            for(int i = 0; i < uPieces.length; i++) //Loops for every value in the list
            {
                if(!(uPieces[i].charAt(0) == '_')) //Adds one to the list count if the value has been replaced yet
                {
                    listCount++;
                }
            }
            
            if(listCount == uPieces.length) //If every value is filled, set it to true
            {
                listPiece = true;
            }
        }
        
        if(difficulty == 2 || difficulty == 3) //Checks if your doing dates
        {
            listCount = 0;
            for(int i = 0; i < uDates.length; i++) //Loops for every value in the list
            {
                if(!(uDates[i] == 0)) //Adds one to the list count if the value has been replaced yet
                {
                    listCount++;
                }
            }
            
            if(listCount == uPieces.length) //If every value is filled, set it to true
            {
                listDate = true;
            }
        }

        if(difficulty == 1 && listPiece) //Checks if the correct list is filled for Name only
        {
            TextArts.SlowPrint("Are you finished? (Y,N): ", false);
            String text = input.nextLine();
            if(text.equals("Y")) //If the user is done, end the loop
            {
                return true;
            }
        }
        
        if(difficulty == 2 && listDate) //Checks if the correct list is filled for Date only
        {
            TextArts.SlowPrint("Are you finished? (Y,N): ", false);
            String text = input.nextLine();
            if(text.equals("Y")) //If the user is done, end the loop
            {
                return true;
            }
        }
        
        if(difficulty == 3 && listDate && listPiece) //Checks if both lists are filled for both list difficulty
        {
            TextArts.SlowPrint("Are you finished? (Y,N): ", false);
            String text = input.nextLine();
            if(text.equals("Y")) //If the user is done, end the loop
            {
                return true;
            }
        }
        
        while(difficult == 3 && tempLoop)
        {
            TextArts.SlowPrint("Which list would you like to access? (1: Date (int), 2: Name (String)): ", false);
            int tempValue = input.nextInt(); 
            if(tempValue == 2) //If using both lists, and want to use the name list, set the values to reflect that
            {
                isPiece = true;
                tempLoop = false;
            }
            else if(tempValue == 1) //If using both lists and want to use the date list, set the values to reflect that
            {
                isPiece = false;
                tempLoop = false;
            }
        }
        
        TextArts.SlowPrint("Which slot would you like to change? (1-7): ", false); 
        int index = input.nextInt(); //grabs the slot for which value
        index -= 1;     //Sets it to work with the list index

        if(isPiece) //If your using names, run this
        {
            input.nextLine(); //This prevents a specific bug of using nextInt and nextLine in a row that eats the "enter" input from nextInt in nextLine, resulting in a null input
            TextArts.SlowPrint("What would you like to put in that slot?: ", false); 
            String tempValue = input.nextLine();
            uPieces[index] = tempValue; //Sets the value in the list to the value inputted
        }
        else //Else, your using dates, run this
        {
            TextArts.SlowPrint("What would you like to put in that slot?: ", false);
            int tempValue = input.nextInt();
            uDates[index] = tempValue; //sets the value in the list to the value inputted
        }
        
        return false;
    }
    
    public static void SpeedFF(String str, boolean slow) //Makes the print instant after a screen clear to give the illusion of changed text instead of full replacement
    {
        if(slow) //If it should be slow
        {
            TextArts.SlowPrint(str, true); //Print it slowly
        }
        else
        {
            System.out.println(str); //Print it fast
        }
    }
    
    public static void SpeedFFQ(String str, boolean slow) //Makes the print instant after a screen clear to give the illusion of changed text instead of full replacement, but for questions
    {
        if(slow)
        {
            TextArts.SlowPrint(str, false); //Print it slowly WITHOUT a line clear to allow an answer to be submitted
        }
        else
        {
            System.out.println(str + difficulty); //Prints it with the answer
        }
    }
}
